//
//  ViewController.swift
//  CPBFB
//
//  Created by Ivan Vassilev on 11/20/22.
//

import UIKit
import Firebase

class ViewController: UIViewController, UITableViewDataSource {
    
    
    @IBOutlet weak var mytableView: UITableView!
    
    
    var colleges: [College] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mytableView.dataSource = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getData()
    }
    
    func getData() {
        let database = Database.database().reference().child("Colleges")
        database.getData { error, dataSnap in
            for data in dataSnap?.children.allObjects as! [DataSnapshot] {
                let name = data.key
                let dictionary = data.value as! NSDictionary
                let location = dictionary["location"] as! String
                let numberOfStudents = dictionary["numberofStudents"] as! String
                let webPage = dictionary["webPage"] as! String
                let currentCollege = College(name: name, location: location, numberofStudents: numberOfStudents, webPage: webPage)
                self.colleges.append(currentCollege)
            }
            self.mytableView.reloadData()
        
        }
    }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return colleges.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
            
            var content = cell.defaultContentConfiguration()
            content.text = colleges[indexPath.row].name //<- what you want to display
            cell.contentConfiguration = content
            
            return cell
            
        }
        @IBAction func addButton(_ sender: Any) {
           
            
            let alert = UIAlertController(title: "Add New College", message: nil, preferredStyle: UIAlertController.Style.alert)
            
            alert.addTextField { (textField) in
                textField.placeholder = "Add College Name Here"
            }
            
            alert.addTextField { (textField) in
                textField.placeholder = "Add College Location Here"
            }
            
            alert.addTextField { (textField) in
                textField.placeholder = "Add Number of Students Here"
            }
            
            alert.addTextField { (textField) in
                textField.placeholder = "Add Webpage URL Here"
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
            alert.addAction(cancelAction)
            
            let addAction = UIAlertAction(title: "Add", style: UIAlertAction.Style.default) { (action) in
                let nameTextField = alert.textFields![0].text!
                let locationTextField = alert.textFields![1].text!
                let numberOfStudentsTextField = alert.textFields![2].text!
                let webPageTextField = alert.textFields![3].text!
                
                
                
                let newCollege = College(name: nameTextField, location: locationTextField, numberofStudents: numberOfStudentsTextField, webPage: webPageTextField)
                
                self.colleges.append(newCollege)
                
                Database.database().reference().child("Colleges")
                self.mytableView.reloadData()
            }
            
          alert.addAction(addAction)
            present(alert, animated: true)
            
        }
        
    }
