//
//  College.swift
//  CPBFB
//
//  Created by Ivan Vassilev on 11/20/22.
//

import Foundation


class College{
var name: String
var location: String
var numberofStudents: String
var webPage: String
    init(name: String, location: String, numberofStudents: String, webPage: String){
        self.name = name
        self.location = location
        self.numberofStudents = numberofStudents
        self.webPage = webPage
    }
}
