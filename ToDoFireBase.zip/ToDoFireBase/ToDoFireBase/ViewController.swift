//
//  ViewController.swift
//  ToDoFireBase
//
//  Created by Lubo Penev on 10/6/22.
//
import FirebaseDatabase
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var tasks: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
     
        }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    func getData() {
        let dataBase = Database.database().reference().child("Tasks")
        dataBase.getData { error, DataSnapshot in
            for data in dataSnapshot?.children.allObjects as! [DataSnapshot]{
                let currentTask = data.value as! String
                self.tasks.append(currentTask)
            }
            self.tableViewe.ReloadData()
        }
    }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "myCell")!
        cell.textLabel?.text = tasks[indexPath.row]
        cell.detailTextLabel?.text = tasks[indexPath.row]
        return cell

    }
        
        @IBAction func addButton(_ sender: UIBarButtonItem) {
            let dataBase = Database.database().reference()
            print(dataBase)
            let count = self.tasks.count
            dataBase.child("Tasks").updateChildValues(["task\(count)":taskText])
           
//
//            let alert = UIAlertController(title: "Add New College", message: nil, preferredStyle: UIAlertController.Style.alert)
//
//            alert.addTextField { (textField) in
//                textField.placeholder = "Add College Name Here"
//            }
//
//            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
//            alert.addAction(cancelAction)
//
//            let addAction = UIAlertAction(title: "Add", style: UIAlertAction.Style.default) { (action) in
//                let nameTextField = alert.textFields?[0]
//                let locationTextField = alert.textFields?[1]
//                let numberOfStudentsTextField = alert.textFields?[2]
//                let webPageTextField = alert.textFields?[3]
//            }
//            alert.addAction(addAction)
//            present(alert, animated: true, completion: nil)
            
        }
        
    }

