//
//  ViewController.swift
//  ToDo
//
//  Created by Lubo Penev on 9/8/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    var college: [College] = []
    
    let bobcontext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
    
    }
    override func viewWillAppear(_ animated: Bool) {
        getData()
        tableView.reloadData()
    }
    
    func getData() {
        if let myTasks = try? bobcontext.fetch(College.fetchRequest()){
            college = myTasks
        } else {
        print("error")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return college.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath as IndexPath)
        var content = cell.defaultContentConfiguration()
        
        
       
        content.text = college[indexPath.row].name
        content.text = college[indexPath.row].location
        content.hasPrefix(Int) -> String = college[indexPath.row].numberStudents
        content.text = college[indexPath.row].webPage
        cell.contentConfiguration = content
        return cell
        
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let task = college[indexPath.row]
            bobcontext.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        }
        tableView.reloadData()
    }
}


