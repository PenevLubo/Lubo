//
//  AddTaskViewController.swift
//  ToDo
//
//  Created by Lubo Penev on 9/8/22.
//

import UIKit

class AddTaskViewController: UIViewController {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var locationTextfield: UITextField!
    @IBOutlet weak var numberStudentsTextField: UITextField!
    @IBOutlet weak var webPageTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        
        guard let collegeName = nameTextField.text else{ return }
        guard let collegeLocation = locationTextfield.text else{return}
        guard let numberOfStudents = numberStudentsTextField.text else {return}
        guard let webPage = webPageTextField.text else {return}
        if let number = Int(numberOfStudents) {
            var number2 = NSNumber(value: number)
            
            
            
            let appdelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appdelegate.persistentContainer.viewContext
            let task = College(context: context)
            task.setValue(collegeLocation, forKey: "location")
            task.setValue(webPage, forKey: "webPage")
            task.setValue(numberOfStudents, forKey: "numberStudents")
            task.setValue(collegeName, forKey: "name")
            appdelegate.saveContext()
        }
        
    }
    
    
    
    
    
}
