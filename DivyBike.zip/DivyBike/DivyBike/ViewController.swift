//
//  ViewController.swift
//  DivyBike
//
//  Created by Lubo Penev on 12/14/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    var stationArray:[String] = []
    let url = URL(string: "https://data.cityofchicago.org/resource/aavc-b2wj.json")!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        getData()
        
    }
    
    func getData() {
        
        URLSession.shared.dataTask(with: url){ data, response, error in
            guard let data = data else {return}
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String:Any]{
                self.stationArray.removeAll()
                let stationName = json["station_name"] as! [String: Any]
                
                 print(stationName)
                
                let arrayList = json[""] as! NSArray
                for element in arrayList {
                    let dictionary = arrayList[0] as! NSDictionary
                }
                
                self.stationArray.append("\(stationName)")
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                //    self.navigationItem.title = "Weather for \(city)"
                }
            }
            
        }.resume()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stationArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        cell.textLabel?.text = stationArray[indexPath.row]
        return cell
    }
}
